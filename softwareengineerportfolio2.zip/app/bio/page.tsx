import type { Metadata } from "next"
import BioPage from "@/components/pages/BioPage"

export const metadata: Metadata = {
  title: "About Precious Udoessien - Software Engineer",
  description:
    "Learn about Precious Udoessien's background, skills, and experience in software engineering, blockchain development, and cybersecurity.",
}

export default function Page() {
  return <BioPage />
}

