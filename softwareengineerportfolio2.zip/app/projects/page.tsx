import type { Metadata } from "next"
import ProjectsPage from "@/components/pages/ProjectsPage"

export const metadata: Metadata = {
  title: "Projects - Precious Udoessien",
  description:
    "Explore the projects developed by Precious Udoessien, showcasing expertise in software engineering, blockchain, and cybersecurity.",
}

export default function Page() {
  return <ProjectsPage />
}

