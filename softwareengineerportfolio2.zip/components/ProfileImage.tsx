"use client"

import Image from "next/image"
import { motion } from "framer-motion"

interface ProfileImageProps {
  className?: string
  size?: "sm" | "md" | "lg"
}

const sizes = {
  sm: "h-12 w-12",
  md: "h-24 w-24",
  lg: "h-48 w-48",
}

export function ProfileImage({ className = "", size = "md" }: ProfileImageProps) {
  return (
    <motion.div
      whileHover={{ scale: 1.05 }}
      transition={{ type: "spring", stiffness: 300, damping: 10 }}
      className={`relative overflow-hidden rounded-full ${sizes[size]} ${className}`}
    >
      <Image
        src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/img-NjCsLoZpByUb5EAngnIlv-0qB6Q9uAaOwPKGABAP0Ns400lW6Svo.jpeg"
        alt="Precious Udoessien"
        fill
        className="object-cover"
        priority
      />
    </motion.div>
  )
}

