"use client"

import { useState } from "react"
import { ProjectCard3D } from "@/components/ProjectCard3D"
import { Button } from "@/components/ui/button"

const projects = [
  {
    name: "AI-based Malware Detector",
    description: "An advanced malware detection system using machine learning algorithms.",
    link: "https://github.com/luckysitara/ML-malware_detector",
    tags: ["Python", "Machine Learning", "Cybersecurity"],
  },
  {
    name: "Solpay",
    description: "A crypto payment gateway built on the Solana blockchain.",
    link: "#",
    tags: ["Rust", "Solana", "Blockchain"],
  },
  {
    name: "v0 Project",
    description: "An interactive AI-powered development environment.",
    link: "https://v0-super-gcksvfxewe4-jszmoo.vercel.app",
    tags: ["Next.js", "AI", "React"],
  },
  {
    name: "Machine Learning Algorithm Trading Bot",
    description: "A bot that uses machine learning to trade stocks.",
    link: "#",
    tags: ["Python", "Machine Learning", "Finance"],
  },
  {
    name: "Voting With Payment System Plugin",
    description: "A plugin that allows users to vote and pay for their votes.",
    link: "#",
    tags: ["PHP", "MySQL", "Payment Gateway"],
  },
  {
    name: "Connect and Build (ecommerce/artisan/client platform)",
    description: "An e-commerce platform for artisans and clients.",
    link: "#",
    tags: ["React", "Node.js", "MongoDB"],
  },
  {
    name: "AI-based Vulnerability Web Tester",
    description: "A web application that tests for vulnerabilities using AI.",
    link: "#",
    tags: ["Python", "AI", "Web Security"],
  },
  {
    name: "Simple Linux Shell",
    description: "A simple Linux shell written in C.",
    link: "https://github.com/luckysitara/simple_shell",
    tags: ["C", "Linux"],
  },
  {
    name: "Nft-mint_vault_swap",
    description: "A platform for minting, storing, and swapping NFTs.",
    link: "https://github.com/luckysitara/Nft-mint_vault_swap",
    tags: ["Solidity", "Ethereum"],
  },
]

const allTags = Array.from(new Set(projects.flatMap((project) => project.tags)))

export default function ProjectsPage() {
  const [selectedTags, setSelectedTags] = useState<string[]>([])

  const filteredProjects =
    selectedTags.length > 0
      ? projects.filter((project) => project.tags.some((tag) => selectedTags.includes(tag)))
      : projects

  const toggleTag = (tag: string) => {
    setSelectedTags((prev) => (prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]))
  }

  return (
    <div className="space-y-8">
      <h1 className="text-4xl font-bold mb-8">My Projects</h1>

      <div className="mb-8">
        <h2 className="text-2xl font-semibold mb-4">Filter by Technology:</h2>
        <div className="flex flex-wrap gap-2">
          {allTags.map((tag) => (
            <Button
              key={tag}
              variant={selectedTags.includes(tag) ? "default" : "outline"}
              onClick={() => toggleTag(tag)}
              className="text-sm"
            >
              {tag}
            </Button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredProjects.map((project, index) => (
          <ProjectCard3D key={index} project={project} />
        ))}
      </div>
    </div>
  )
}

