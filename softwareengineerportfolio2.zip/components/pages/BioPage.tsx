"use client"

import { motion } from "framer-motion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ProfileImage } from "@/components/ProfileImage"
import { SkillsShowcase } from "@/components/SkillsShowcase"
import { Timeline } from "@/components/Timeline"

export default function BioPage() {
  const experiences = [
    {
      title: "Ethical Hacker & Backend Developer",
      company: "Netisens ICT",
      period: "May 2023 - Present",
      description:
        "Implemented robust security measures through penetration testing. Contributed to backend development projects.",
    },
    {
      title: "CEO & Founder",
      company: "Bugacademy, Solpay",
      period: "2022 - Present",
      description: "Developed Solpay, a crypto payment gateway. Established and managed an e-learning platform.",
    },
  ]

  const certifications = [
    "Alx Africa Software Engineering Certification (2024)",
    "Google Coursera Cyber Security Certification (2023)",
    "Advent of Cyber (2023)",
    "AI Career Essential (ALX Africa)",
    "Blockchain Engineer (in progress)",
  ]

  return (
    <div className="space-y-12 animate-fadeIn">
      <section className="prose prose-lg dark:prose-invert max-w-none">
        <div className="flex flex-col md:flex-row md:items-start md:space-x-8">
          <motion.div
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="mb-8 md:mb-0"
          >
            <ProfileImage size="lg" className="shadow-lg" />
          </motion.div>
          <div className="space-y-4 flex-1">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <h1 className="text-4xl font-bold mb-4">About Me</h1>
              <div className="space-y-4">
                <p>
                  Hi, I'm Precious Udoessien, a certified Software Engineer with a strong background in building secure,
                  decentralized applications using Rust and Anchor in the Solana blockchain network. My focus is on
                  enhancing user experiences and developing scalable, secure solutions that solve real-world problems.
                </p>
                <p>
                  With expertise in software development, cybersecurity, and blockchain technology, I bridge the gap
                  between technical development and practical applications. I'm committed to delivering innovative and
                  security-focused solutions that streamline operations, improve efficiency, and drive growth.
                </p>
                <p>
                  I'm always looking for new challenges and opportunities to apply my skills to impactful projects. If
                  you're seeking someone who can transform your software ideas into secure, functional, and
                  high-performing products, let's connect and explore how we can work together.
                </p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.6 }}
      >
        <SkillsShowcase />
      </motion.section>

      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.8 }}
      >
        <h2 className="text-2xl font-bold mb-4">Professional Experience</h2>
        <Timeline items={experiences} />
      </motion.section>

      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 1 }}
      >
        <h2 className="text-2xl font-bold mb-4">Certifications</h2>
        <Card>
          <CardHeader>
            <CardTitle>Professional Certifications</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="list-disc list-inside space-y-2">
              {certifications.map((cert, index) => (
                <li key={index}>{cert}</li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </motion.section>
    </div>
  )
}

