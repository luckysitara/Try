"use client"

import { TypeAnimation } from "react-type-animation"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { motion } from "framer-motion"
import { ParticlesContainer } from "@/components/ParticlesContainer"

export function HeroSection() {
  return (
    <section className="relative flex min-h-[80vh] flex-col items-center justify-center text-center">
      <ParticlesContainer />
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="z-10 space-y-6"
      >
        <h1 className="mb-4 text-5xl font-bold sm:text-6xl md:text-7xl">
          <span className="bg-gradient-to-r from-blue-500 to-blue-700 bg-clip-text text-transparent">
            Precious Udoessien
          </span>
        </h1>
        <TypeAnimation
          sequence={[
            "Software Engineer",
            2000,
            "Blockchain Developer",
            2000,
            "Cybersecurity Expert",
            2000,
            "Ethical Hacker",
            2000,
          ]}
          wrapper="p"
          speed={50}
          className="mb-8 text-2xl text-blue-800 dark:text-blue-200 sm:text-3xl md:text-4xl"
          repeat={Number.POSITIVE_INFINITY}
        />
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="flex flex-wrap justify-center gap-4"
        >
          <Button asChild size="lg" className="btn-primary">
            <Link href="/bio">About Me</Link>
          </Button>
          <Button
            asChild
            variant="outline"
            size="lg"
            className="border-blue-500 text-blue-800 dark:text-blue-200 hover:bg-blue-100 dark:hover:bg-blue-900/50"
          >
            <Link href="/portfolio">My Work</Link>
          </Button>
          <Button
            asChild
            variant="secondary"
            size="lg"
            className="bg-blue-100 text-blue-800 hover:bg-blue-200 dark:bg-blue-900/50 dark:text-blue-200 dark:hover:bg-blue-800/50"
          >
            <Link href="/contact">Get in Touch</Link>
          </Button>
        </motion.div>
      </motion.div>
    </section>
  )
}

