"use client"

import { Overview } from "../components/dashboard/overview"

export default function SyntheticV0PageForDeployment() {
  return <Overview />
}

