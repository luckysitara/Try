import Link from "next/link"
import Image from "next/image"
import { ModeToggle } from "./ModeToggle"

export default function Header() {
  return (
    <header className="sticky top-0 z-50 border-b border-blue-900/50 bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <nav className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2 group">
            <div className="relative h-8 w-8 overflow-hidden rounded-full">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 to-cyan-500 opacity-75 blur group-hover:opacity-100 transition-opacity" />
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/DALL%C2%B7E%202025-02-22%2008.20.51%20-%20A%20futuristic%20logo%20for%20'bughacker'.%20The%20design%20features%20a%20stylized%20bug%20icon%20integrated%20with%20circuit%20lines,%20symbolizing%20hacking%20and%20security.%20The%20text%20'-apq5N9NoUEZNAUxpMy6RgPqbhc1Lz6.webp"
                alt="Bughacker"
                fill
                className="relative object-contain p-0.5"
              />
            </div>
            <span className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
              BH
            </span>
          </Link>
          <ul className="flex items-center space-x-6">
            <li>
              <Link href="/" className="text-gray-200 hover:text-blue-400 transition-colors">
                Home
              </Link>
            </li>
            <li>
              <Link href="/bio" className="text-gray-200 hover:text-blue-400 transition-colors">
                Bio
              </Link>
            </li>
            <li>
              <Link href="/portfolio" className="text-gray-200 hover:text-blue-400 transition-colors">
                Portfolio
              </Link>
            </li>
            <li>
              <Link href="/contact" className="text-gray-200 hover:text-blue-400 transition-colors">
                Contact
              </Link>
            </li>
            <li>
              <ModeToggle />
            </li>
          </ul>
        </div>
      </nav>
    </header>
  )
}

