"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import { ProfileImage } from "./ProfileImage"

export function BrandedHeader() {
  return (
    <div className="relative w-full overflow-hidden bg-gradient-to-b from-[#050A1C] via-background to-background py-12">
      <div className="absolute inset-0 opacity-50">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-blue-500/20 via-transparent to-transparent" />
      </div>
      <div className="container relative mx-auto px-4">
        <div className="flex flex-col items-center md:flex-row md:justify-between">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-8 flex items-center md:mb-0"
          >
            <ProfileImage size="lg" className="mr-8 border-2 border-blue-500 shadow-[0_0_15px_rgba(0,180,255,0.3)]" />
            <div>
              <h1 className="mb-2 text-4xl font-bold">
                <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
                  Bughacker
                </span>
              </h1>
              <p className="text-lg text-gray-100">Precious Udoessien</p>
              <p className="text-sm text-blue-200">Cybersecurity Expert & Blockchain Developer</p>
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="relative h-32 w-32"
          >
            <div className="absolute -inset-0.5 rounded-full bg-gradient-to-r from-blue-500 to-cyan-500 opacity-75 blur" />
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/DALL%C2%B7E%202025-02-22%2008.20.51%20-%20A%20futuristic%20logo%20for%20'bughacker'.%20The%20design%20features%20a%20stylized%20bug%20icon%20integrated%20with%20circuit%20lines,%20symbolizing%20hacking%20and%20security.%20The%20text%20'-apq5N9NoUEZNAUxpMy6RgPqbhc1Lz6.webp"
              alt="Bughacker Cybersecurity"
              fill
              className="relative rounded-full object-contain p-0.5"
              priority
            />
          </motion.div>
        </div>
      </div>
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-background" />
    </div>
  )
}

