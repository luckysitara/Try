"use client"

import { TypeAnimation } from "react-type-animation"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ParticlesContainer } from "@/components/ParticlesContainer"

export function HeroSection() {
  return (
    <section className="relative flex min-h-[60vh] flex-col items-center justify-center text-center">
      <ParticlesContainer />
      <div className="z-10 space-y-6">
        <h1 className="mb-4 text-5xl font-bold sm:text-6xl md:text-7xl">
          <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
            Precious Udoessien
          </span>
        </h1>
        <TypeAnimation
          sequence={["Software Engineer", 2000, "Blockchain Developer", 2000, "Cybersecurity Expert", 2000]}
          wrapper="p"
          speed={50}
          className="mb-8 text-2xl text-blue-100 sm:text-3xl md:text-4xl"
          repeat={Number.POSITIVE_INFINITY}
        />
        <div className="flex flex-wrap justify-center gap-4">
          <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700">
            <Link href="/bio">About Me</Link>
          </Button>
          <Button asChild variant="outline" size="lg" className="border-blue-500 text-blue-100 hover:bg-blue-900/50">
            <Link href="/portfolio">My Work</Link>
          </Button>
          <Button asChild variant="secondary" size="lg" className="bg-blue-900/50 text-blue-100 hover:bg-blue-800/50">
            <Link href="/contact">Get in Touch</Link>
          </Button>
        </div>
      </div>
    </section>
  )
}

