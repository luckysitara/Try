"use client"

import { ProjectCard3D } from "@/components/ProjectCard3D"
import { ScrollReveal } from "@/components/ScrollReveal"
import { FaYoutube } from "react-icons/fa"
import Link from "next/link"

export default function Portfolio() {
  const projects = [
    {
      name: "AI-based Malware Detector",
      description: "An advanced malware detection system using machine learning algorithms.",
      link: "https://github.com/luckysitara/ML-malware_detector",
      tags: ["Python", "Machine Learning", "Cybersecurity"],
    },
    {
      name: "Solpay",
      description: "A crypto payment gateway built on the Solana blockchain.",
      link: "#",
      tags: ["Rust", "Solana", "Blockchain"],
    },
    {
      name: "v0 Project",
      description: "An interactive AI-powered development environment.",
      link: "https://v0-super-gcksvfxewe4-jszmoo.vercel.app",
      tags: ["Next.js", "AI", "React"],
    },
    {
      name: "Machine Learning Algorithm Trading Bot",
      description: "A bot that uses machine learning to trade stocks.",
      link: "#",
      tags: ["Python", "Machine Learning", "Finance"],
    },
    {
      name: "Voting With Payment System Plugin",
      description: "A plugin that allows users to vote and pay for their votes.",
      link: "#",
      tags: ["PHP", "MySQL", "Payment Gateway"],
    },
    {
      name: "Connect and Build (ecommerce/artisan/client platform)",
      description: "An e-commerce platform for artisans and clients.",
      link: "#",
      tags: ["React", "Node.js", "MongoDB"],
    },
    {
      name: "AI-based Vulnerability Web Tester",
      description: "A web application that tests for vulnerabilities using AI.",
      link: "#",
      tags: ["Python", "AI", "Web Security"],
    },
    {
      name: "Simple Linux Shell",
      description: "A simple Linux shell written in C.",
      link: "https://github.com/luckysitara/simple_shell",
      tags: ["C", "Linux"],
    },
    {
      name: "Nft-mint_vault_swap",
      description: "A platform for minting, storing, and swapping NFTs.",
      link: "https://github.com/luckysitara/Nft-mint_vault_swap",
      tags: ["Solidity", "Ethereum"],
    },
    {
      name: "Sql-checker",
      description: "A tool for checking SQL queries for vulnerabilities.",
      link: "#",
      tags: ["Python", "SQL"],
    },
    {
      name: "Encryptor",
      description: "A tool for encrypting and decrypting files.",
      link: "https://github.com/luckysitara/Encryptor",
      tags: ["Python", "Cryptography"],
    },
  ]

  return (
    <div className="space-y-8">
      <ScrollReveal>
        <h1 className="text-4xl font-bold mb-8">My Projects</h1>
      </ScrollReveal>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {projects.map((project, index) => (
          <ScrollReveal key={index} delay={index * 0.1}>
            <ProjectCard3D project={project} />
          </ScrollReveal>
        ))}
      </div>

      <ScrollReveal>
        <div className="mt-8 space-y-6">
          <h2 className="text-2xl font-bold mb-4">Team Project</h2>
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <FaYoutube className="text-red-600 text-2xl" />
              <Link
                href="https://youtube.com/watch?v=your-team-project-video-id"
                className="text-primary hover:underline"
                target="_blank"
                rel="noopener noreferrer"
              >
                Watch our team project video
              </Link>
            </div>
            <div>
              <Link
                href="https://www.canva.com/design/DAGb5Jjl4-c/B-IMhenyETAxRsFnFe31sg/edit?utm_content=DAGb5Jjl4-c&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton"
                className="text-primary hover:underline"
                target="_blank"
                rel="noopener noreferrer"
              >
                View our team project slide deck
              </Link>
            </div>
          </div>
        </div>
      </ScrollReveal>

      <ScrollReveal>
        <div className="mt-8">
          <h2 className="text-2xl font-bold mb-4">Elevator Pitch</h2>
          <div className="flex items-center gap-4">
            <FaYoutube className="text-red-600 text-2xl" />
            <Link
              href="https://youtu.be/xp63pcbDnrA?si=L4ojYfnezh-WH_xs"
              className="text-primary hover:underline"
              target="_blank"
              rel="noopener noreferrer"
            >
              Watch my elevator pitch
            </Link>
          </div>
        </div>
      </ScrollReveal>
    </div>
  )
}

