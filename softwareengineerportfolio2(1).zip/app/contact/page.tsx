import type { Metadata } from "next"
import ContactPage from "@/components/pages/ContactPage"

export const metadata: Metadata = {
  title: "Contact - Precious Udoessien",
  description: "Get in touch with Precious Udoessien for collaboration opportunities.",
}

export default function Page() {
  return <ContactPage />
}

