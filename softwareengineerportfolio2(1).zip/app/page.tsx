import type { Metadata } from "next"
import HomePage from "@/components/pages/HomePage"

export const metadata: Metadata = {
  title: "Precious Udoessien - Software Engineer Portfolio",
  description: "Portfolio of Precious Udoessien, a software engineer specializing in blockchain and cybersecurity.",
}

export default function Page() {
  return <HomePage />
}

