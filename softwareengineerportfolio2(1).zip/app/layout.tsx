import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { FloatingActionButton } from "@/components/FloatingActionButton"
import { ParticlesContainer } from "@/components/ParticlesContainer"
import { LoadingScreen } from "@/components/LoadingScreen"
import { Suspense } from "react"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Precious Udoessien - Software Engineer Portfolio",
  description: "Portfolio of Precious Udoessien, a software engineer specializing in blockchain and cybersecurity.",
  keywords: ["Software Engineer", "Blockchain Developer", "Cybersecurity Expert", "Rust Developer", "Solana"],
  authors: [{ name: "Precious Udoessien" }],
  openGraph: {
    type: "website",
    title: "Precious Udoessien - Software Engineer Portfolio",
    description: "Portfolio of Precious Udoessien, a software engineer specializing in blockchain and cybersecurity.",
  },
  generator: "v0.dev",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
          <LoadingScreen />
          <div className="relative min-h-screen">
            <Suspense fallback={null}>
              <ParticlesContainer />
            </Suspense>
            <div className="relative z-10">
              <Header />
              <main className="container mx-auto px-4 py-8">{children}</main>
              <Footer />
              <FloatingActionButton />
            </div>
          </div>
        </ThemeProvider>
      </body>
    </html>
  )
}

import "./globals.css"



import './globals.css'