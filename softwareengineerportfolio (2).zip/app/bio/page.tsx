import { Progress } from "@/components/ui/progress"
import { DownloadCV } from "@/components/DownloadCV"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ProfileImage } from "@/components/ProfileImage"
import { ScrollReveal } from "@/components/ScrollReveal"

export default function Bio() {
  const skills = [
    { name: "Rust", level: 90 },
    { name: "Solana", level: 85 },
    { name: "Ethical Hacking", level: 95 },
    { name: "Python", level: 80 },
    { name: "React", level: 75 },
  ]

  const experiences = [
    {
      title: "Ethical Hacker & Backend Developer",
      company: "Netisens ICT",
      period: "May 2023 - Present",
      description:
        "Implemented robust security measures through penetration testing. Contributed to backend development projects.",
    },
    {
      title: "CEO & Founder",
      company: "Bugacademy, Solpay",
      period: "2022 - Present",
      description: "Developed Solpay, a crypto payment gateway. Established and managed an e-learning platform.",
    },
  ]

  const certifications = [
    "Alx Africa Software Engineering Certification (2024)",
    "Google Coursera Cyber Security Certification (2023)",
    "Advent of Cyber (2023)",
    "AI Career Essential (ALX Africa)",
    "Blockchain Engineer (in progress)",
  ]

  return (
    <div className="space-y-12 animate-fadeIn">
      <section className="prose prose-lg dark:prose-invert">
        <div className="flex flex-col items-center md:flex-row md:items-start md:space-x-8">
          <ScrollReveal>
            <ProfileImage size="lg" className="mb-8 md:mb-0" />
          </ScrollReveal>
          <div className="space-y-4">
            <ScrollReveal>
              <h1 className="text-4xl font-bold mb-4">About Me</h1>
              <div className="space-y-4">
                <p>
                  Hi, my name is Precious Udoessien. I'm a certified Software Engineer with a strong background in
                  building secure, decentralized applications using Rust and Anchor in the Solana blockchain network.
                  With a focus on enhancing user experiences and developing scalable, secure solutions, I bring
                  expertise in software development, cybersecurity, problem-solving, and adapting complex systems to
                  meet user needs.
                </p>
                <p>
                  What makes me stand out is my ability to bridge technical development with real-world applications,
                  creating not just functional products but secure solutions that solve tangible problems in industries
                  like finance and healthcare. I am committed to delivering innovative and security-focused solutions
                  that will streamline operations, improve efficiency, and drive growth for employers or clients.
                </p>
                <p>
                  I'm currently looking for opportunities where I can apply my skills to impactful projects. If you're
                  looking for someone who can take your software ideas and turn them into secure, functional,
                  high-performing products, let's connect.
                </p>
                <p>Together, we can build solutions that make a difference.</p>
              </div>
            </ScrollReveal>
            <ScrollReveal delay={0.2}>
              <div className="mt-8">
                <DownloadCV />
              </div>
            </ScrollReveal>
          </div>
        </div>
      </section>

      <ScrollReveal>
        <section>
          <h2 className="text-2xl font-bold mb-4">Skills</h2>
          <div className="space-y-4">
            {skills.map((skill, index) => (
              <div key={index}>
                <div className="flex justify-between mb-1">
                  <span>{skill.name}</span>
                  <span>{skill.level}%</span>
                </div>
                <Progress value={skill.level} className="w-full" />
              </div>
            ))}
          </div>
        </section>
      </ScrollReveal>

      <ScrollReveal>
        <section>
          <h2 className="text-2xl font-bold mb-4">Experience</h2>
          <div className="space-y-4">
            {experiences.map((exp, index) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle>{exp.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="font-semibold">{exp.company}</p>
                  <p className="text-sm text-muted-foreground">{exp.period}</p>
                  <p className="mt-2">{exp.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      </ScrollReveal>

      <ScrollReveal>
        <section>
          <h2 className="text-2xl font-bold mb-4">Certifications</h2>
          <ul className="list-disc list-inside space-y-2">
            {certifications.map((cert, index) => (
              <li key={index}>{cert}</li>
            ))}
          </ul>
        </section>
      </ScrollReveal>
    </div>
  )
}

